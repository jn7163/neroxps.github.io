# README

1.驱动仅适用于 ALC233，注入 ID4
2.运行 alc_fix install.sh


